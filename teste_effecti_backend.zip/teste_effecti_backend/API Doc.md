# Sistema de Gerenciamento de Licitações

## 📝 Descrição
Sistema desenvolvido em Spring Boot para captura e gerenciamento de licitações públicas do ComprasNet.

## 🛠️ Tecnologias Utilizadas
- Java 17
- Spring Boot 3.5.3
- PostgreSQL
- Lombok
- JSoup
- Jakarta Validation

## 📁 Estrutura do Projeto

### 📦 Pacotes Principais

#### 🔧 Config
- **CorsConfig**: 
  - Define as configurações de cors, para gerenciar o acesso de URLs
-**PaginateResponse**
  - Classe que representa o modelo de resposta para paginação.

#### 🎮 Controller
- **LicitacaoController**: Controlador REST para operações com licitações
  - Endpoint para captura automática de licitações
  - Endpoint para consulta com filtros por UASG e número do pregão
  - Documentação Swagger integrada

#### 📊 DTO (Data Transfer Objects)
- **LicitacaoDTO**: Objeto de transferência para licitações
  - Usado para comunicação entre front-end e back-end
  - Otimiza a transferência de dados

#### ⚠️ Exception
- **GlobalExceptionHandler**: Tratamento centralizado de exceções
  - Padroniza respostas de erro da API
  - Melhora a experiência do usuário com mensagens adequadas

#### 📋 Model
- **Licitacao**: Entidade principal do sistema
  - Mapeamento JPA para persistência
  - Validações com Jakarta Validation
  - Documentação Swagger integrada

#### 📁 Repository
- **LicitacaoRepository**: Interface de acesso aos dados
  - Extends JpaRepository
  - Métodos de consulta personalizados
  - Operações CRUD básicas

#### 🔄 Service
- **LicitacaoService**: Camada de serviço
  - Implementa a lógica de negócio
  - Gerencia a captura de licitações
  - Processa filtros e consultas

#### 🚀 Classe Principal
- **TesteEffectiBackendApplication**: Ponto de entrada da aplicação
  - Configuração do Spring Boot
  - Inicialização do contexto da aplicação

## 🌟 Funcionalidades Principais
1. Captura automática de licitações do ComprasNet
2. Armazenamento em banco de dados PostgreSQL
3. Consulta de licitações com filtros
