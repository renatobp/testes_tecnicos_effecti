package br.com.rbp.teste_effecti_backend.service;

import br.com.rbp.teste_effecti_backend.config.PaginatedResponse;
import br.com.rbp.teste_effecti_backend.dto.LicitacaoDTO;
import br.com.rbp.teste_effecti_backend.model.Licitacao;
import br.com.rbp.teste_effecti_backend.repository.LicitacaoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

/**
 * Classe de testes unitários para {@link LicitacaoService}.
 * Utiliza o framework Mockito para simulação de dependências.
 */
@ExtendWith(MockitoExtension.class)
class LicitacaoServiceTest {

    /** Mock do repositório de licitações */
    @Mock
    private LicitacaoRepository repository;

    /** Instância do serviço a ser testado com mocks injetados */
    @InjectMocks
    private LicitacaoService service;

    /** Objeto mock de licitação para uso nos testes */
    private Licitacao licitacaoMock1;
    
    /** Segundo objeto mock de licitação para uso nos testes */
    private Licitacao licitacaoMock2;

    /**
     * Configuração inicial executada antes de cada teste.
     * Prepara os objetos mock de licitação com dados de teste.
     */
    @BeforeEach
    void setUp() {
        licitacaoMock1 = Licitacao.builder()
                .id(1L)
                .codigoUasg("123456")
                .numeroPregao("001/2025")
                .objeto("Aquisição de equipamentos")
                .dataEdital("01/07/2025")
                .endereco("Rua Teste, 123")
                .telefone("(11) 1234-5678")
                .fax("(11) 1234-5679")
                .entregaProposta("05/07/2025 às 10:00")
                .build();

        licitacaoMock2 = Licitacao.builder()
                .id(2L)
                .codigoUasg("123456")
                .numeroPregao("002/2025")
                .objeto("Contratação de serviços")
                .dataEdital("02/07/2025")
                .endereco("Rua Teste, 456")
                .telefone("(11) 9876-5432")
                .fax("(11) 9876-5433")
                .entregaProposta("06/07/2025 às 14:00")
                .build();
    }

    /**
     * Classe aninhada para agrupar testes relacionados ao método buscarLicitacoes.
     */
    @Nested
    @DisplayName("Testes para o método buscarLicitacoes")
    class BuscarLicitacoesTest {

        /**
         * Testa o cenário onde são fornecidos tanto o código UASG quanto o número do pregão.
         * Deve retornar apenas as licitações que correspondem exatamente aos critérios.
         */
        @Test
        @DisplayName("Deve retornar lista filtrada quando informado código UASG e número do pregão")
        void deveRetornarListaFiltradaQuandoInformadoUasgEPregao() {
            when(repository.findByCodigoUasgAndNumeroPregao("123456", "001/2025"))
                    .thenReturn(Arrays.asList(licitacaoMock1));
            PaginatedResponse<LicitacaoDTO> resultado = service.buscarLicitacoes("123456", "001/2025", 1, 10);
            verify(repository).findByCodigoUasgAndNumeroPregao("123456", "001/2025");
        }

        /**
         * Testa o cenário onde nenhum filtro é fornecido.
         * Deve retornar todas as licitações cadastradas no sistema.
         */
        @Test
        @DisplayName("Deve retornar todas as licitações quando não informado filtros")
        void deveRetornarTodasLicitacoesQuandoSemFiltros() {
            // Arrange
            when(repository.findAll())
                    .thenReturn(Arrays.asList(licitacaoMock1, licitacaoMock2));
            PaginatedResponse<LicitacaoDTO> resultado = service.buscarLicitacoes(null, null, 0,0);
            verify(repository).findAll();
        }
    }
}