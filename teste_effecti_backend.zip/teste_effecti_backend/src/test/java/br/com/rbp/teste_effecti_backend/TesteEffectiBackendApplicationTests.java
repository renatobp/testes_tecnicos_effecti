package br.com.rbp.teste_effecti_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteEffectiBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
