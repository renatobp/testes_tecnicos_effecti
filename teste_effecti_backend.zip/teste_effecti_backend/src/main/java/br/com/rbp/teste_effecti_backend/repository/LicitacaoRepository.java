package br.com.rbp.teste_effecti_backend.repository;

import br.com.rbp.teste_effecti_backend.model.Licitacao;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@Repository
@Tag(name = "Repository de Licitações", description = "Repositório para operações de persistência de licitações")
public interface LicitacaoRepository extends JpaRepository<Licitacao, Long> {
    
    @Operation(summary = "Buscar por UASG e número do pregão",
            description = "Busca licitações filtrando pelo código UASG e número do pregão")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Licitações encontradas"),
        @ApiResponse(responseCode = "404", description = "Nenhuma licitação encontrada")
    })
    List<Licitacao> findByCodigoUasgAndNumeroPregao(
            @Parameter(description = "Código da UASG", example = "153080") String codigoUasg,
            @Parameter(description = "Número do pregão", example = "10/2024") String numeroPregao);
}