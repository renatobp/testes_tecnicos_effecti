package br.com.rbp.teste_effecti_backend.config;

import java.util.List;

public class PaginatedResponse<T> {
    private List<T> data;
    private int total;
    private int page;

    public PaginatedResponse(List<T> data, int total, int page) {
        this.data = data;
        this.total = total;
        this.page = page;
    }

    public List<T> getData() {
        return data;
    }

    public int getTotal() {
        return total;
    }

    public int getPage() {
        return page;
    }
}