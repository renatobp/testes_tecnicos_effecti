package br.com.rbp.teste_effecti_backend.controller;

import br.com.rbp.teste_effecti_backend.config.PaginatedResponse;
import br.com.rbp.teste_effecti_backend.dto.LicitacaoDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import br.com.rbp.teste_effecti_backend.service.LicitacaoService;

import java.io.IOException;
import java.util.List;

/**
 * Controlador REST responsável por expor os endpoints relacionados às operações com licitações.
 * Fornece endpoints para captura e consulta de licitações públicas.
 */
@RestController
@RequestMapping("/api/licitacoes")
@Tag(name = "Licitações", description = "API para gerenciamento de licitações públicas")
public class LicitacaoController {

    @Autowired
    private LicitacaoService service;

    @Operation(summary = "Captura licitações do ComprasNet",
            description = "Realiza a captura das licitações disponíveis no dia atual no portal ComprasNet")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Licitações capturadas com sucesso"),
        @ApiResponse(responseCode = "500", description = "Erro ao capturar licitações")
    })
    @PostMapping("/capturar")
    public ResponseEntity<Void> capturarLicitacoes() throws IOException {
        service.capturarLicitacoes();
        return ResponseEntity.ok().build();
    }

    @Operation(summary = "Lista licitações",
            description = "Retorna uma lista paginada de licitações com base nos filtros fornecidos")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Licitações encontradas"),
            @ApiResponse(responseCode = "404", description = "Nenhuma licitação encontrada")
    })
    @GetMapping
    public ResponseEntity<PaginatedResponse<LicitacaoDTO>> listarLicitacoes(
            @Parameter(description = "Código da UASG para filtrar", example = "153080")
            @RequestParam(required = false) String codigoUasg,

            @Parameter(description = "Número do pregão para filtrar", example = "10/2024")
            @RequestParam(required = false) String numeroPregao,

            @Parameter(description = "Número da página (começando em 1)", example = "1")
            @RequestParam(defaultValue = "1") int page,

            @Parameter(description = "Quantidade de itens por página", example = "10")
            @RequestParam(defaultValue = "10") int limit) {

        PaginatedResponse<LicitacaoDTO> response = service.buscarLicitacoes(codigoUasg, numeroPregao, page, limit);
        return ResponseEntity.ok(response);
    }
}