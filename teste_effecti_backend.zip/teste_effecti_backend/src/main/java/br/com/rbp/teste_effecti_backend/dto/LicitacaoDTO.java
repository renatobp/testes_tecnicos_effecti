package br.com.rbp.teste_effecti_backend.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Dados de uma licitação")
public class LicitacaoDTO {
    @Schema(description = "Código identificador da Unidade Administrativa de Serviços Gerais")
    private String codigoUasg;
    
    @Schema(description = "Número identificador do pregão")
    private String numeroPregao;
    
    @Schema(description = "Descrição do objeto da licitação")
    private String objeto;
    
    @Schema(description = "Data de publicação do edital")
    private String dataEdital;
    
    @Schema(description = "Endereço relacionado à licitação")
    private String endereco;
    
    @Schema(description = "Número de telefone para contato")
    private String telefone;
    
    @Schema(description = "Número do fax para contato")
    private String fax;
    
    @Schema(description = "Data e hora limite para entrega da proposta")
    private String entregaProposta;
}