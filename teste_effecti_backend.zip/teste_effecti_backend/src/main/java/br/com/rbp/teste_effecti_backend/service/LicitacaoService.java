package br.com.rbp.teste_effecti_backend.service;

import br.com.rbp.teste_effecti_backend.config.PaginatedResponse;
import br.com.rbp.teste_effecti_backend.dto.LicitacaoDTO;
import br.com.rbp.teste_effecti_backend.model.Licitacao;
import org.jsoup.nodes.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import br.com.rbp.teste_effecti_backend.repository.LicitacaoRepository;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class LicitacaoService {

    @Autowired
    private LicitacaoRepository repository;

    private List<Licitacao> buscarLicitacoesFiltradas(String codigoUasg, String numeroPregao) {
        if (codigoUasg != null && numeroPregao != null) {
            return repository.findByCodigoUasgAndNumeroPregao(codigoUasg, numeroPregao);
        }
        return repository.findAll();
    }

    private PaginatedResponse<LicitacaoDTO> paginar(List<LicitacaoDTO> dtos, int page, int limit) {
        int start = (page - 1) * limit;
        int end = Math.min(start + limit, dtos.size());
        List<LicitacaoDTO> paginatedDtos = dtos.subList(start, end);
        return new PaginatedResponse<>(paginatedDtos, dtos.size(), page);
    }

    public PaginatedResponse<LicitacaoDTO> buscarLicitacoes(String codigoUasg, String numeroPregao, int page, int limit) {
        List<Licitacao> licitacoes = buscarLicitacoesFiltradas(codigoUasg, numeroPregao);
        List<LicitacaoDTO> dtos = licitacoes.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());

        return paginar(dtos, page, limit);
    }

    public void capturarLicitacoes() throws IOException {
        String url = "http://comprasnet.gov.br/ConsultaLicitacoes/ConsLicitacaoDia.asp";
        Document doc = Jsoup.connect(url)
                .userAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/115.0.0.0")
                .timeout(30000)
                .get();

        Elements rows = doc.select("table tr");
        List<Licitacao> licitacoesParaSalvar = new ArrayList<>();

        for (Element row : rows) {
            try {
                String rowText = row.text();

                // Verifica se a linha contém as informações necessárias
                if (rowText.contains("Código da UASG:") && rowText.contains("Pregão Eletrônico Nº")) {
                    Licitacao.LicitacaoBuilder licitacaoBuilder = Licitacao.builder();

                    // Extrai o código UASG
                    String uasgPattern = "Código da UASG:\\s*(\\d+)";
                    Pattern pattern = Pattern.compile(uasgPattern);
                    Matcher matcher = pattern.matcher(rowText);
                    if (matcher.find()) {
                        licitacaoBuilder.codigoUasg(matcher.group(1));
                    }

                    // Extrai o número do pregão
                    String pregaoPattern = "Pregão Eletrônico Nº (\\d+/\\d+)";
                    pattern = Pattern.compile(pregaoPattern);
                    matcher = pattern.matcher(rowText);
                    if (matcher.find()) {
                        licitacaoBuilder.numeroPregao(matcher.group(1));
                    }

                    // Extrai o objeto
                    String objetoPattern = "Objeto: (.+?) Edital a partir de:";
                    pattern = Pattern.compile(objetoPattern);
                    matcher = pattern.matcher(rowText);
                    if (matcher.find()) {
                        licitacaoBuilder.objeto(matcher.group(1).trim());
                    }

                    // Extrai a data do edital
                    String dataEditalPattern = "Edital a partir de: (\\d{2}/\\d{2}/\\d{4})";
                    pattern = Pattern.compile(dataEditalPattern);
                    matcher = pattern.matcher(rowText);
                    if (matcher.find()) {
                        licitacaoBuilder.dataEdital(matcher.group(1));
                    }

                    // Extrai o endereço
                    String enderecoPattern = "Endereço: (.+?) Telefone:";
                    pattern = Pattern.compile(enderecoPattern);
                    matcher = pattern.matcher(rowText);
                    if (matcher.find()) {
                        licitacaoBuilder.endereco(matcher.group(1).trim());
                    }

                    // Extrai o telefone
                    String telefonePattern = "Telefone:\\s*([^F][^a][^x].+?)(?=\\s+Fax:)";
                    pattern = Pattern.compile(telefonePattern);
                    matcher = pattern.matcher(rowText);
                    if (matcher.find()) {
                        licitacaoBuilder.telefone(matcher.group(1).trim());
                    }

                    // Extrai o fax
                    String faxPattern = "Fax:\\s*(.+?)(?=\\s+Entrega da Proposta:)";
                    pattern = Pattern.compile(faxPattern);
                    matcher = pattern.matcher(rowText);
                    if (matcher.find()) {
                        licitacaoBuilder.fax(matcher.group(1).trim());
                    }

                    // Extrai a data da proposta
                    String dataPropostaPattern = "Entrega da Proposta: (\\d{2}/\\d{2}/\\d{4} às \\d{2}:\\d{2})Hs";
                    pattern = Pattern.compile(dataPropostaPattern);
                    matcher = pattern.matcher(rowText);
                    if (matcher.find()) {
                        licitacaoBuilder.entregaProposta(matcher.group(1));
                    }

                    // Constrói o objeto Licitacao usando o builder
                    Licitacao licitacao = licitacaoBuilder.build();

                    // Só adiciona se tiver os dados básicos
                    if (licitacao.getCodigoUasg() != null && licitacao.getNumeroPregao() != null) {
                        licitacoesParaSalvar.add(licitacao);
                        System.out.println("Licitação encontrada: UASG " + licitacao.getCodigoUasg() +
                                " - Pregão " + licitacao.getNumeroPregao());
                    }
                }
            } catch (Exception e) {
                System.err.println("Erro ao processar linha: " + e.getMessage());
                e.printStackTrace();
            }
        }

        if (!licitacoesParaSalvar.isEmpty()) {
            System.out.println("\nSalvando " + licitacoesParaSalvar.size() + " licitações...");
            repository.saveAll(licitacoesParaSalvar);
            System.out.println("Licitações salvas com sucesso!");
        } else {
            System.out.println("\nNenhuma licitação válida encontrada para salvar");
        }
    }

    private LicitacaoDTO convertToDTO(Licitacao licitacao) {
        LicitacaoDTO dto = new LicitacaoDTO();
        dto.setCodigoUasg(licitacao.getCodigoUasg());
        dto.setNumeroPregao(licitacao.getNumeroPregao());
        dto.setObjeto(licitacao.getObjeto());
        dto.setDataEdital(licitacao.getDataEdital());
        dto.setEndereco(licitacao.getEndereco());
        dto.setTelefone(licitacao.getTelefone());
        dto.setFax(licitacao.getFax());
        dto.setEntregaProposta(licitacao.getEntregaProposta());
        return dto;
    }
}