package br.com.rbp.teste_effecti_backend.exception;

import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.server.ResponseStatusException;

@RestControllerAdvice
@Schema(description = "Manipulador global de exceções da aplicação")
public class GlobalExceptionHandler {

    record ErrorResponse(String message) {}

    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<ErrorResponse> handleNotFoundException(ResponseStatusException ex) {
        return new ResponseEntity<>(
            new ErrorResponse(ex.getReason() != null ? ex.getReason() : "Recurso não encontrado"), 
            ex.getStatusCode()
        );
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGlobalException(Exception ex) {
        return new ResponseEntity<>(
            new ErrorResponse("Ocorreu um erro interno"), 
            HttpStatus.INTERNAL_SERVER_ERROR
        );
    }
}