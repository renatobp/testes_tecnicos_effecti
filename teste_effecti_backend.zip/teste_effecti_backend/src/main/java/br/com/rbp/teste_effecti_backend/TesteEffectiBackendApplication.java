package br.com.rbp.teste_effecti_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesteEffectiBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TesteEffectiBackendApplication.class, args);
	}

}
