package br.com.rbp.teste_effecti_backend.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Schema(description = "Entidade que representa uma Licitação no sistema")
@Data
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Licitacao {
    
    @Schema(description = "Identificador único da licitação", example = "1")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Schema(description = "Código da Unidade Administrativa de Serviços Gerais", example = "153080")
    @Column(length = 20000)
    private String codigoUasg;
    
    @Schema(description = "Número identificador do pregão", example = "10/2024")
    @Column(length = 50)
    private String numeroPregao;
    
    @Schema(description = "Descrição detalhada do objeto da licitação")
    @Column(length = 20000)
    private String objeto;
    
    @Schema(description = "Data de publicação do edital", example = "01/07/2024")
    @Column(length = 50)
    private String dataEdital;
    
    @Schema(description = "Endereço completo relacionado à licitação")
    @Column(length = 20000)
    private String endereco;
    
    @Schema(description = "Número de telefone para contato", example = "(11) 1234-5678")
    @Column(length = 20000)
    private String telefone;

    @Schema(description = "Número do fax para contato", example = "(11) 1234-5679")
    @Column(length = 20000)
    private String fax;

    @Schema(description = "Data e hora limite para entrega da proposta", example = "15/07/2024 às 10:00")
    @Column(length = 20000)
    private String entregaProposta;
}