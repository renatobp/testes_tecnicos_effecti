describe('LicitacaoController - listarLicitacoes', () => {
  it('deve retornar licitações paginadas e filtradas', () => {

    cy.request('http://localhost:8080/api/licitacoes',{
      method: 'GET',
      qs: {
        page: 1,
        limit: 5,
        codigoUasg: '1234',
        numeroPregao: '5678'
      }
    }).then((response) => {
      expect(response.status).toEqual(200);
      expect(response.body).toHaveProperty('codigoUasg');
      expect(response.body).toHaveProperty('numeroPregao');
      expect(response.body).toHaveProperty('data');
      expect(response.body).toHaveProperty('total');
      expect(response.body).toHaveProperty('page');

      expect(response.body.data).toBe('array');
      response.body.data.forEach((licitacao) => {
        expect(licitacao.codigoUasg).toContain('1234');
        expect(licitacao.numeroPregao).toContain('5678');
      });
    });
  });
});
