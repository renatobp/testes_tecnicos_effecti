export interface Licitacao {
  id: string;
  codigoUasg: string;
  numeroPregao: string;
  objeto: string;
  dataEdital: string;
  endereco: string;
  telefone: string;
  fax: string;
  entregaProposta: string;
}
