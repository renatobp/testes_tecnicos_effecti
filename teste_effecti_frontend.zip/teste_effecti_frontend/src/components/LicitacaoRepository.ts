import type { Licitacao } from '@/components/Licitacao';

export class LicitacaoRepository {
  private licitacoes: Licitacao[] = [];

  constructor() {
    this.licitacoes = [];
  }

  async findAll(): Promise<Licitacao[]> {
    return [...this.licitacoes];
  }
}
