<template>
  <div class="page-background">
    <div class="container">
      <h1 class="title">Sistema de Licitações</h1>

      <!-- Adicionar indicador de carregamento -->
      <div v-if="isLoading" class="loading-indicator">
        Carregando...
      </div>

      <!-- Após o div de loading -->
      <div v-if="error" class="error-message">
        {{ error }}
      </div>

      <div class="form-container">
        <div class="form-grid">
          <div class="form-group">
            <label>UASG</label>
            <input
              v-model="filters.codigoUasg"
              type="text"
              placeholder="Digite o código UASG"
            >
          </div>

          <div class="form-group">
            <label>Número do Pregão</label>
            <input
              v-model="filters.numeroPregao"
              type="text"
              placeholder="Digite o número do pregão"
            >
          </div>

          <div class="button-container">
            <button
              @click="buscarLicitacoes"
              :disabled="isLoading"
              class="search-button"
            >
              {{ isLoading ? 'Buscando...' : 'Buscar' }}
            </button>
          </div>
        </div>
      </div>

      <div class="table-container">
        <div v-if="!isLoading && (!paginationState.data || paginationState.data.length === 0)" class="no-data-message">
          Nenhuma licitação encontrada
        </div>

        <div v-else>
          <LicitacaoTable :items="paginationState.data"/>
        </div>

        <div v-if="paginationState.data.length > 0" class="pagination">
          <span class="total-records">
            Total: {{ paginationState.total }} registros
          </span>
          <div class="pagination-buttons">
            <button
              @click="mudarPagina(paginationState.page - 1)"
              :disabled="paginationState.page <= 1"
              class="pagination-button"
            >
              Anterior
            </button>
            <button
              @click="mudarPagina(paginationState.page + 1)"
              :disabled="paginationState.page >= Math.ceil(paginationState.total / paginationState.limit)"
              class="pagination-button"
            >
              Próxima
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue';
import axios from 'axios';
import type { Licitacao } from '@/components/Licitacao.ts';
import { usePaginationManager } from '@/composables/usePaginationManager.ts';
import LicitacaoTable from '@/components/LicitacaoTable.vue'

const API_URL = 'http://localhost:8080/api';
const isLoading = ref(false);

const { paginationManager, paginationState } = usePaginationManager<Licitacao>(10);

interface Filters {
  codigoUasg: string;
  numeroPregao: string;
}

const filters = ref<Filters>({
  codigoUasg: '',
  numeroPregao: ''
});

// No script setup
const error = ref<string | null>(null);

async function buscarLicitacoes() {
  isLoading.value = true;
  error.value = null;

  try {
    const params = {
      ...paginationManager.getPaginationParams(),
      ...filters.value
    };

    const response = await axios.get(`${API_URL}/licitacoes`, { params });

    if (!response.data) {
      throw new Error('Resposta vazia da API');
    }

    // Garantir que temos as propriedades necessárias
    if (!('data' in response.data) || !('total' in response.data) || !('page' in response.data)) {
      throw new Error('Resposta da API em formato inválido');
    }

    paginationManager.updateState({
      data: response.data.data || [],
      total: response.data.total || 0,
      page: response.data.page || 1
    });

  } catch (error:any) {
    console.error('Erro na busca:', error);
    error.value = 'Erro ao carregar licitações. Por favor, tente novamente.';
  } finally {
    isLoading.value = false;
  }
}

function mudarPagina(novaPagina: number) {
  if (novaPagina < 1) return;
  paginationManager.setPage(novaPagina);
  buscarLicitacoes();
}

// Garantir que a busca inicial seja executada após a montagem do componente
onMounted(() => {
  buscarLicitacoes();
});
</script>

<style scoped>
.page-background {
  min-height: 100vh;
  background: linear-gradient(135deg, #000C24 0%, #001A4D 100%);
  display: flex;
  align-items: center;
}

.container {
  width: 100%;
}

.form-container {
  margin: 0 auto;
  width: 600px;
}

.title{
  text-align: center;
}

.loading-indicator{
  text-align: center;
  font-size: x-large;
}

.no-data-message{
  text-align: center;
}

th, td {
  text-align: left;
  padding: 1rem;
  color: white;
}

th {
  background: rgba(0, 0, 0, 0.2);
  font-weight: 500;
}

tr {
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

tr:last-child {
  border-bottom: none;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.form-group label {
  color: white;
  font-size: 0.9rem;
}

.form-group input {
  padding: 0.75rem;
  border-radius: 4px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  background: rgba(255, 255, 255, 0.05);
  color: white;
  width: 100%;
  box-sizing: border-box;
}

.form-group input:focus {
  outline: none;
  border-color: #3b82f6;
}

.button-container {
  grid-column: 1 / -1;
  display: flex;
  justify-content: center;
  margin-top: 1rem;
}

.search-button {
  background: #3b82f6;
  color: white;
  border: none;
  padding: 0.75rem 2rem;
  border-radius: 4px;
  cursor: pointer;
  min-width: 150px;
}

.search-button:hover {
  background: #2563eb;
}

.search-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

table {
  width: 100%;
  border-collapse: collapse;
}

.pagination {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.total-records {
  color: white;
}

.pagination-buttons {
  display: flex;
  gap: 0.5rem;
}

.pagination-button {
  padding: 0.5rem 1rem;
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
  border-radius: 4px;
  cursor: pointer;
}

.pagination-button:hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.2);
}

.pagination-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

@media (max-width: 768px) {
  .form-grid {
    grid-template-columns: 1fr;
  }

  .pagination {
    flex-direction: column;
    gap: 1rem;
  }
}

.error-message {
  background-color: #fee2e2;
  color: #dc2626;
  padding: 1rem;
  margin: 1rem 0;
  border-radius: 4px;
  text-align: center;
}

/* Adicionar estilos para melhor visualização da tabela com mais colunas */
.table-container {
  overflow-x: auto; /* Permite rolagem horizontal em telas pequenas */
}

table {
  min-width: 1200px; /* Largura mínima para acomodar todas as colunas */
}

td {
  max-width: 300px; /* Largura máxima para células */
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>
