<template>
  <table>
    <thead>
    <tr>
      <th>UASG</th>
      <th>Pregão</th>
      <th>Objeto</th>
      <th>Data do Edital</th>
      <th>Endereço</th>
      <th>Telefone</th>
      <th>Fax</th>
      <th>Entrega da Proposta</th>
    </tr>
    </thead>
    <tbody>
    <tr v-for="licitacao in items" :key="licitacao.id">
      <td>{{ licitacao.codigoUasg }}</td>
      <td>{{ licitacao.numeroPregao }}</td>
      <td>{{ licitacao.objeto }}</td>
      <td>{{ formatarData(licitacao.dataEdital) }}</td>
      <td>{{ licitacao.endereco }}</td>
      <td>{{ licitacao.telefone }}</td>
      <td>{{ licitacao.fax }}</td>
      <td>{{ licitacao.entregaProposta }}</td>
    </tr>
    </tbody>
  </table>
</template>

<script setup lang="ts">
import type { Licitacao } from '@/components/Licitacao.ts';

defineProps<{
  items: Licitacao[]
}>();

function formatarData(data: string): string {
  if (!data) return '';
  try {
    return new Date(data).toLocaleDateString('pt-BR');
  } catch (error) {
    console.error('Erro ao formatar data:', error);
    return data;
  }
}
</script>

<style scoped>

</style>
