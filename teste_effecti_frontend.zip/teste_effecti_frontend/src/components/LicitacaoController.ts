import { LicitacaoRepository } from "./LicitacaoRepository";
import type { Request, Response } from 'express';
import type { Licitacao } from '@/components/Licitacao';

interface PaginatedResponse {
  data: Licitacao[];
  total: number;
  page: number;
}

export class LicitacaoController {
  private licitacaoRepository: LicitacaoRepository;

  constructor() {
    this.licitacaoRepository = new LicitacaoRepository();
  }

  async listarLicitacoes(req: Request, res: Response): Promise<void> {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const codigoUasg = req.query.codigoUasg as string;
      const numeroPregao = req.query.numeroPregao as string;

      let todasLicitacoes = await this.licitacaoRepository.findAll();

      // Aplicar filtros
      if (codigoUasg) {
        todasLicitacoes = todasLicitacoes.filter(l =>
          l.codigoUasg.toLowerCase().includes(codigoUasg.toLowerCase())
        );
      }
      if (numeroPregao) {
        todasLicitacoes = todasLicitacoes.filter(l =>
          l.numeroPregao.toLowerCase().includes(numeroPregao.toLowerCase())
        );
      }

      const total = todasLicitacoes.length;
      const inicio = (page - 1) * limit;
      const fim = inicio + limit;
      const licitacoesPaginadas = todasLicitacoes.slice(inicio, fim);

      const response: PaginatedResponse = {
        data: licitacoesPaginadas,
        total,
        page
      };

      res.json(response);
    } catch (error) {
      console.error('Erro ao listar licitações:', error);
      res.status(500).json({ error: 'Erro ao listar licitações' });
    }
  }
}
