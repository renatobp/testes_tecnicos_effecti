import { ref } from 'vue';

interface PaginationState<T> {
  data: T[];
  page: number;
  limit: number;
  total: number;
}

interface UpdateStateParams<T> {
  data: T[];
  total: number;
  page: number;
}

export function usePaginationManager<T>(initialLimit: number = 10) {
  const paginationState = ref<PaginationState<T>>({
    data: [],
    page: 1,
    limit: initialLimit,
    total: 0
  });

  const paginationManager = {
    getPaginationParams() {
      return {
        page: paginationState.value.page,
        limit: paginationState.value.limit
      };
    },

    setPage(page: number) {
      paginationState.value.page = page;
    },

    updateState({ data, total, page }: UpdateStateParams<T>) {
      paginationState.value = {
        ...paginationState.value,
        data,
        total,
        page
      };
    }
  };

  return {
    paginationManager,
    paginationState
  };
}
